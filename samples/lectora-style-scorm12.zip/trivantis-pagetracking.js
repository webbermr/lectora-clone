function PageTrackingObj() { this.numPages = 0; this.title = null; }
PageTrackingObj.prototype.find = function (n, id) { if (n.id == id) return n; for (var i = 0; n.c && i < n.c.length; i++) { var m = this.find(n.c[i], id); if (m) return m; } return null; };
PageTrackingObj.prototype.SetRangeStatus = function (id, s) { var n = this.find(this.title, id); if (n) n.v = s; };
var trivPageTracking = new PageTrackingObj();
trivPageTracking.numPages = 21;

trivPageTracking.publishTimeStamp = 2026101012000;

trivPageTracking.title={id:1,v:0,c:[{id:100,v:0},{id:200,v:0,c:[{id:1000,v:0},{id:1001,v:0},{id:1002,v:0}]},{id:300,v:0,c:[{id:1003,v:0},{id:1004,v:0},{id:1005,v:0},{id:1006,v:0},{id:1007,v:0}]},{id:400,v:0,c:[{id:1008,v:0},{id:1009,v:0},{id:1010,v:0}]},{id:500,v:0,c:[{id:1011,v:0},{id:1012,v:0}]},{id:700,v:0,t:1,c:[{id:710,v:0,c:[{id:7710,v:0},{id:7711,v:0},{id:7712,v:0}]},{id:720,v:0,c:[{id:7720,v:0},{id:7721,v:0}]},{id:790,v:0}]},{id:900,v:0}]};
