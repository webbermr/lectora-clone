// Minimal stand-in for Lectora's runtime, for this sample only.
function Variable(name, def) { this.name = name; this.def = def; }
Variable.prototype.getValue = function () { var v = sessionStorage.getItem(this.name); return v === null ? this.def : v; };
Variable.prototype.set = function (v) { sessionStorage.setItem(this.name, String(v)); };
Variable.prototype.equals = function (v) { return this.getValue() == v; };
Variable.prototype.add = function (n) { this.set(Number(this.getValue()) + Number(n)); };
Variable.prototype.lessThan = function (v) { return Number(this.getValue()) < Number(v); };
function ObjProgress(name, alt, x, y, w, h, vis, z, a, b, c, d, e, f, min, max) { this.name = name; this.min = min; this.max = max; }
function trivExitPage(page) { location.href = page; }
// Like Lectora's runtime, this names a debug window learners never open.
function trivDebug() { window.open('trivantisdebug.html'); }
