var api = (function f(w){ for (var i=0;i<10&&w;i++){ if (w.API_1484_11) return w.API_1484_11; if (w.parent===w) break; w=w.parent; } return null; })(window);
if (api) { api.Initialize(''); api.SetValue('cmi.completion_status','completed'); api.Commit(''); }
window.addEventListener('pagehide', function(){ if (api) api.Terminate(''); });