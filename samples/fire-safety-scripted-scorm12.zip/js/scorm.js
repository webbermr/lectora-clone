var API = null;
function findAPI(win) { for (var i = 0; i < 10 && win; i++) { if (win.API) return win.API; if (win.parent === win) break; win = win.parent; } return null; }
API = findAPI(window);
if (API) { API.LMSInitialize(''); }
function markComplete() { if (API) { API.LMSSetValue('cmi.core.lesson_status', 'completed'); API.LMSCommit(''); } }
window.onunload = function () { if (API) API.LMSFinish(''); };