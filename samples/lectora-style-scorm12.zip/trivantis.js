// Minimal stand-in for Lectora's runtime, for this sample only.
function Variable(name, def) { this.name = name; this.def = def; }
Variable.prototype.getValue = function () { var v = sessionStorage.getItem(this.name); return v === null ? this.def : v; };
Variable.prototype.set = function (v) { sessionStorage.setItem(this.name, String(v)); };
Variable.prototype.equals = function (v) { return this.getValue() == v; };
function trivExitPage(page) { location.href = page; }
