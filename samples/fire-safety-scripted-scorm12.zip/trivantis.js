/* tiny stand-in for an authoring tool's runtime */
function ObjInline(id, x, y, w, html) { this.id = id; this.x = x; this.y = y; this.w = w; this.html = html; }
ObjInline.prototype.build = function () {
  var d = document.createElement('div');
  d.id = this.id;
  d.style.cssText = 'position:absolute;left:' + this.x + 'px;top:' + this.y + 'px;width:' + this.w + 'px';
  d.innerHTML = this.html;
  document.getElementById('stage').appendChild(d);
};
function ObjImage(id, x, y, w, src) { this.id = id; this.x = x; this.y = y; this.w = w; this.src = src; }
ObjImage.prototype.build = function () {
  var i = new Image();
  i.id = this.id; i.src = this.src; i.alt = '';
  i.style.cssText = 'position:absolute;left:' + this.x + 'px;top:' + this.y + 'px;width:' + this.w + 'px';
  document.getElementById('stage').appendChild(i);
};
function ObjButton(id, x, y, label, target) { this.id = id; this.x = x; this.y = y; this.label = label; this.target = target; }
ObjButton.prototype.build = function () {
  var b = document.createElement('button');
  b.id = this.id; b.textContent = this.label; var t = this.target;
  b.style.cssText = 'position:absolute;left:' + this.x + 'px;top:' + this.y + 'px;padding:8px 20px;background:#b22;color:#fff;border:0;border-radius:4px';
  b.onclick = function () { location.href = t; };
  document.getElementById('stage').appendChild(b);
};
