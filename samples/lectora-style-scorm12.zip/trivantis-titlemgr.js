// Stand-in for Lectora's title manager, for this sample only.
function TitleMgr() {}
var TMPr = TitleMgr.prototype;
var hlf = CJ.AES.dct;
var utf8 = CJ.enc.Utf8;

//LD-5993
TMPr.bDc = function(str) {
  var rur  = hlf(str, 'lectora-clone-sample');
  var ret = rur.toString(utf8);
  return ret;
}
