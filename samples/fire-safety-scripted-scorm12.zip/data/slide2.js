window.slideData = {"title":"Extinguisher types","lines":["Water \u2014 for paper and wood","CO\u2082 \u2014 for electrical fires","Always check the gauge before use"]};
